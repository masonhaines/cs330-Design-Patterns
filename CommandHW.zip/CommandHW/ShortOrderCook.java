public class ShortOrderCook { // Receiver

    public void makeBurger()
    {
        System.out.println("Making your burger!");
    }

    public void makeShake()
    {
        System.out.println("Making your shake!");
    }
}
