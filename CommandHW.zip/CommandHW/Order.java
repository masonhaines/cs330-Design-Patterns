public interface Order { // Command interface 

    public void execute(); // OrderUp

}
